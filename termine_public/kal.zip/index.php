<?php

require("assets/functions/functions.php");
require 'assets/functions/CSRF_Protect.php';
$csrf = new CSRF_Protect();

error_reporting(E_ALL);

?>
<!DOCTYPE html>
<html lang="de">

	<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="Event Calendar">
		<meta name="author" content="EZCode.de">
		<link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon" >

		<title></title>

		<!-- Bootstrap Core CSS -->
		<link href="assets/css/bootstrap.min.css" rel="stylesheet">

		<!-- Custom CSS -->
		<link href="assets/css/styles.css" rel="stylesheet">	

		<!-- DateTimePicker CSS -->
		<link href="assets/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">	

		<!-- DataTables CSS -->
		<link href="assets/css/dataTables.bootstrap.css" rel="stylesheet">	

		<!-- FullCalendar CSS -->
		<link href="assets/css/fullcalendar.css" rel="stylesheet" />
		<link href="assets/css/fullcalendar.print.css" rel="stylesheet" media="print" />	

		<!-- jQuery -->
		<script src="assets/js/jquery.js"></script>	

		<!-- SweetAlert CSS -->
		<script src="assets/js/sweetalert.min.js"></script> 
		<link rel="stylesheet" type="text/css" href="assets/css/sweetalert.css">

		<!-- Custom Fonts -->
		<link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
		<!-- ColorPicker CSS -->
		<link href="assets/css/bootstrap-colorpicker.css" rel="stylesheet">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
 <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
 <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
   <![endif]-->

	</head>

	<body>
		<div id="eventcalendar"></div>
		<div class="content-section-a">

			<!--BEGIN PLUGIN -->
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="panel panel-default dash">

							<div class="panel panel-default">
								
								<?php if ($administrator) {  ?>

								<?php } ?>					
								<div class="panel-body">
									<div class="table-responsive">

										<div class="col-lg-12">
											<div id="events"></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
		<!-- /.container -->

		<!-- Bootstrap Core JavaScript -->
		<script src="assets/js/bootstrap.min.js"></script>
		<!-- DataTables JavaScript -->
		<script src="assets/js/jquery.dataTables.js"></script>
		<script src="assets/js/dataTables.bootstrap.js"></script>
		<!-- Listings JavaScript delete options-->
		<script src="assets/js/listings.js"></script>
		<!-- Metis Menu Plugin JavaScript -->
		<script src="assets/js/metisMenu.min.js"></script>
		<!-- Moment JavaScript -->
		<script src="assets/js/moment.min.js"></script>
		<!-- FullCalendar JavaScript -->
		<script src="assets/js/fullcalendar.js"></script>
		<!-- FullCalendar Language JavaScript Selector -->
		<script src='assets/lang/de-ch.js'></script>
		<!-- DateTimePicker JavaScript -->
		<script type="text/javascript" src="assets/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>

		<!-- ColorPicker JavaScript -->
		<script src="assets/js/bootstrap-colorpicker.js"></script>
		<!-- Plugin Script Initialization for DataTables -->


		<?php echo listEvents(); ?>


	</body>

</html>